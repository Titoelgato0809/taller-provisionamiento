<?php
// Conexión a la base de datos PostgreSQL en la VM db
$conn = pg_connect("host=192.168.56.11 dbname=webdb user=vagrant password=vagrant");

if (!$conn) {
    die("❌ Error de conexión a la base de datos.");
}

// Consulta a la tabla de ejemplo
$result = pg_query($conn, "SELECT * FROM usuarios;");

echo "<h2>Usuarios registrados:</h2>";
echo "<ul>";

while ($row = pg_fetch_assoc($result)) {
    echo "<li>" . $row['id'] . " - " . $row['nombre'] . "</li>";
}

echo "</ul>";

pg_close($conn);
?>
