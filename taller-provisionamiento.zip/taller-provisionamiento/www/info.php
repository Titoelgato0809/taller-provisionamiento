<?php
  echo "<h1>Hello desde PHP</h1>";
  phpinfo();
?>
