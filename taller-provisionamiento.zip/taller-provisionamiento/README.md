Taller de Provisionamiento con Vagrant
Objetivo:
Implementar un entorno de aprovisionamiento con dos máquinas virtuales usando Vagrant y VirtualBox.
Una máquina web (Apache + PHP) y una máquina db (PostgreSQL).
Ambas conectadas por red privada para que el sitio web muestre datos desde la base de datos.
Estructura del proyecto:
taller-vagrant/
Vagrantfile
provision-web.sh
provision-db.sh
www/
index.html
info.php
dbtest.php
usuarios.php
Configuración de las máquinas virtuales
Archivo Vagrantfile:
Define dos máquinas: una web y una db.
La web tiene la IP 192.168.56.10 y la db tiene la IP 192.168.56.11.
Cada una ejecuta su propio script de provisionamiento.
Máquina Web
Archivo provision-web.sh:
Actualiza el sistema, instala Apache, PHP y la extensión php-pgsql.
Inicia Apache y enlaza la carpeta compartida del proyecto a /var/www/html.
Archivos web:
index.html → página de prueba.
info.php → muestra configuración de PHP.
dbtest.php → verifica la conexión con la base de datos.
usuarios.php → conecta con PostgreSQL y muestra los datos.
Máquina DB
Archivo provision-db.sh:
Instala PostgreSQL y crea el usuario y base de datos:
Usuario: talleruser
Contraseña: 12345
Base de datos: tallerdb
Tabla: usuarios (id SERIAL, nombre VARCHAR(50))
Inserta tres registros: Saith, María y Luis.
Configuraciones adicionales:
En postgresql.conf se cambia:
listen_addresses = '*'
En pg_hba.conf se agrega:
host all all 192.168.56.10/32 md5
Conexión entre las máquinas
Desde la máquina web:
ping 192.168.56.11
psql -h 192.168.56.11 -U talleruser -d tallerdb
Script PHP usuarios.php
Conecta con PostgreSQL usando:
host=192.168.56.11 dbname=tallerdb user=talleruser password=12345
Ejecuta SELECT * FROM usuarios y muestra los resultados en una lista HTML.
Resultado final
URL: http://192.168.56.10/usuarios.php
Salida esperada:
Usuarios registrados:
1 - Saith
2 - María
3 - Luis