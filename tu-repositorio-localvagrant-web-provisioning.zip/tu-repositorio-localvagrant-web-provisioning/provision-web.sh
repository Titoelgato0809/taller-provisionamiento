#!/bin/bash

# Actualizar el sistema e instalar Apache, PHP, y php-pgsql (necesario para el reto)
sudo apt-get update -y
sudo apt-get install -y apache2 php libapache2-mod-php php-pgsql

# Copiar los archivos del proyecto local a la carpeta de Apache
# /vagrant es la carpeta compartida en la VM
cp -r /vagrant/* /var/www/html/ 

# Reiniciar Apache
sudo service apache2 restart