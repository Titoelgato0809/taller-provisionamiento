<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estado del Servidor - Conexión DB</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 40px;
            background-color: #f4f7f6;
            color: #333;
            line-height: 1.6;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        }
        h1 {
            color: #2c3e50;
            text-align: center;
            margin-bottom: 20px;
            font-size: 2.2em;
        }
        h2 {
            color: #34495e;
            border-bottom: 2px solid #eee;
            padding-bottom: 10px;
            margin-top: 30px;
            font-size: 1.6em;
        }
        .status-message {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: bold;
            font-size: 1.1em;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .status-success {
            background-color: #e6ffe6;
            color: #28a745;
            border: 1px solid #28a745;
        }
        .status-error {
            background-color: #ffe6e6;
            color: #dc3545;
            border: 1px solid #dc3545;
        }
        .status-icon {
            margin-right: 10px;
            font-size: 1.5em;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 25px 0;
            font-size: 0.9em;
            text-align: left;
        }
        table thead tr {
            background-color: #007bff;
            color: #ffffff;
            text-align: left;
        }
        table th, table td {
            padding: 12px 15px;
            border: 1px solid #ddd;
        }
        table tbody tr:nth-of-type(even) {
            background-color: #f3f3f3;
        }
        table tbody tr:hover {
            background-color: #f1f1f1;
        }
        p {
            margin-bottom: 10px;
        }
        .footer {
            text-align: center;
            margin-top: 40px;
            font-size: 0.8em;
            color: #777;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Estado del Entorno Vagrant</h1>

        <?php
        // --- Datos de Conexión a la Base de Datos (Máquina DB) ---
        $host = '192.168.33.11';
        $dbname = 'app_db';
        $user = 'app_user';
        $password = 'secret';

        try {
            // Intentar la conexión usando PDO (PHP Data Objects)
            $pdo = new PDO("pgsql:host=$host;dbname=$dbname", $user, $password);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            echo '<div class="status-message status-success"><span class="status-icon">✔</span> Conexión a PostgreSQL Exitosa!</div>';
            echo '<p>El servidor WEB (<code>192.168.33.10</code>) se ha conectado correctamente a la DB (<code>192.168.33.11</code>).</p>';
            
            // Consultar los datos de prueba insertados por provision-db.sh
            $stmt = $pdo->query('SELECT nombre, precio FROM productos ORDER BY id');
            $productos = $stmt->fetchAll(PDO::FETCH_ASSOC);

            echo '<h2>Productos en la Base de Datos (`app_db`):</h2>';
            if (count($productos) > 0) {
                echo '<table>';
                echo '<thead><tr><th>Nombre</th><th>Precio</th></tr></thead>';
                echo '<tbody>';
                
                foreach ($productos as $producto) {
                    echo '<tr>';
                    echo '<td>' . htmlspecialchars($producto['nombre']) . '</td>';
                    echo '<td>$' . number_format($producto['precio'], 2) . '</td>';
                    echo '</tr>';
                }
                echo '</tbody>';
                echo '</table>';
            } else {
                echo '<p>No hay productos en la base de datos.</p>';
            }

        } catch (PDOException $e) {
            // Si la conexión falla
            echo '<div class="status-message status-error"><span class="status-icon">✖</span> Error de Conexión a la Base de Datos</div>';
            echo '<p>No se pudo conectar a la base de datos en <code>192.168.33.11</code>.</p>';
            echo '<p>Asegúrate que la máquina \'db\' esté corriendo (<code>vagrant up db</code>) y que la configuración de red sea correcta.</p>';
            echo '<p>Detalle del error: ' . htmlspecialchars($e->getMessage()) . '</p>';
        }
        ?>
        <div class="footer">
            Entorno Vagrant &bull; PHP &bull; PostgreSQL &bull; Desarrollado por Saith Gurrute Granada
        </div>
    </div>
</body>
</html>