#!/bin/bash

# Este script instala y configura PostgreSQL en la máquina DB

echo "--- Actualizando paquetes e instalando PostgreSQL ---"
apt-get update -y
apt-get install -y postgresql postgresql-contrib

# 1. Configurar PostgreSQL para escuchar conexiones externas (de la web)
# La versión por defecto de Focal es PostgreSQL 12
PG_CONF="/etc/postgresql/12/main/postgresql.conf"
HBA_CONF="/etc/postgresql/12/main/pg_hba.conf"

echo "listen_addresses = '*'" >> $PG_CONF

# 2. Permitir la conexión desde la IP del servidor web (192.168.33.10)
# 'trust' significa que no pide contraseña, lo cual es común en entornos de desarrollo/Vagrant.
echo "host all all 192.168.33.10/32 trust" >> $HBA_CONF

# Reiniciar el servicio para aplicar los cambios
service postgresql restart

# 3. Crear el usuario y la base de datos de la aplicación
echo "--- Creando usuario y base de datos 'app_db' ---"
# Creamos un usuario de DB llamado 'app_user' con contraseña 'secret'
sudo -u postgres psql -c "CREATE USER app_user WITH PASSWORD 'secret';"
# Creamos la base de datos 'app_db' y asignamos 'app_user' como dueño
sudo -u postgres psql -c "CREATE DATABASE app_db OWNER app_user;"

# 4. Insertar una tabla y datos de prueba
echo "--- Creando tabla e insertando datos de ejemplo ---"
sudo -u postgres psql -d app_db -c "
CREATE TABLE productos (
    id serial PRIMARY KEY,
    nombre VARCHAR ( 50 ) NOT NULL,
    precio DECIMAL(10, 2)
);
"

sudo -u postgres psql -d app_db -c "INSERT INTO productos (nombre, precio) VALUES ('Laptop', 1200.00), ('Monitor', 300.50), ('Teclado', 75.99);"

echo "--- Provisionamiento de DB completado ---"